import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Posting extends LoginAuthentication{

    @Test
    public void posting() throws InterruptedException {
        driver.get("https://www.reddit.com/login");

        login();

        WebElement post = wait.until(ExpectedConditions.elementToBeClickable(By.tagName("textArea")));
        post.sendKeys("this is a test");
        post.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER);// "it just works" - Todd Howard
    }
}
