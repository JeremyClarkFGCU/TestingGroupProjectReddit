import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Commenting extends LoginAuthentication{
    @Before
    public void setup(){
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");
        ChromeDriver driver = new ChromeDriver(options);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));

        driver.get("https://www.reddit.com/r/testingPostFunction/comments/1bzws0h/just_a_test/");
        driver.manage().window().maximize();
    }
    @Test
    public void postAComment() throws InterruptedException {
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.tagName("input")));
        loginLink.sendKeys(Keys.TAB,Keys.ENTER);
        Thread.sleep(2000);

        login();
        Thread.sleep(2000);

        WebElement c = driver.findElement(By.className("public-DraftStyleDefault-block"));
        c.sendKeys("well that just happened.");
        Thread.sleep(2000);
        WebElement comment = driver.findElement(By.className("_22S4OsoDdOqiM-hPTeOURa"));
        comment.sendKeys(Keys.ENTER);
    }
    //@After
    //public void wrapUp () { driver.quit(); }
}
