import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Login extends LoginAuthentication {
    @Before
    public void setup(){
        driver.get("https://www.reddit.com/login");
        driver.manage().window().maximize();
    }
    @Test
    public void failedLogin() throws InterruptedException {
        login("WrongPassword","WrongUsername");
        Thread.sleep(5000);
        clear();
    }

    @Test
    public void successfulLogin() throws InterruptedException {
        login();
        Thread.sleep(1000);
    }
    @Test
    public void signOut(){
        WebElement findDropDownMenu = wait.until(ExpectedConditions.elementToBeClickable(By.id("USER_DROPDOWN_ID")));
        findDropDownMenu.click();

        WebElement logOut = driver.findElement(By.className("GCltVwsXPu5lE-gs4Nucu"));
        // this look stupid but it gets results
        logOut.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER);
    }
    @After
    public void wrapUp(){ driver.quit(); }
}
