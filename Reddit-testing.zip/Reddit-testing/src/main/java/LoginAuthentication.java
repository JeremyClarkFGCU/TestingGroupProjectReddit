import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class LoginAuthentication {
    ChromeOptions options = new ChromeOptions();
    ChromeDriver driver = new ChromeDriver(options);
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
    WebElement username = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-username")));
    WebElement pass = driver.findElement(By.id("login-password"));

    public void clear(){
        username.sendKeys(Keys.CONTROL + "a");
        username.sendKeys(Keys.DELETE);

        pass.sendKeys(Keys.CONTROL + "a");
        pass.sendKeys(Keys.DELETE);
    }
    public void login() throws InterruptedException {
        username.sendKeys("CurbSideBabyDropOff");// could change user
        pass.sendKeys("@Bcm4fbby0112"); // could change password
        pass.sendKeys(Keys.TAB);
        pass.sendKeys(Keys.ENTER);
    }
    public void login(String badPass, String badUser){
        username.sendKeys(badUser);// could change user

        pass.sendKeys(badPass); // could change password
        pass.sendKeys(Keys.TAB);
        pass.sendKeys(Keys.ENTER);
    }
}
